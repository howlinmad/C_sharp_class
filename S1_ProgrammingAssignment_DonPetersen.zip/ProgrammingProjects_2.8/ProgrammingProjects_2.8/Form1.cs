﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        double quarters, dimes, nickels, pennies;
        
        
        public Form1()
        {
            InitializeComponent();
           

        }
                    

        private void calculateButton_Click(object sender, EventArgs e)
        {

            double myTotal;
            string quarterInput = QuartersTextbox.Text;
            string dimesInput = dimesTextBox.Text;
            string nickelInput = nickelsTextBox.Text;
            string penniesInput = penniesTextBox.Text;

            quarters = Convert.ToDouble(quarterInput);
            dimes = Convert.ToDouble(dimesInput);
            nickels = Convert.ToDouble(nickelInput);
            pennies = Convert.ToDouble(penniesInput);



            myTotal = (quarters * 0.25) + (dimes * 0.1) + (nickels * 0.05) + (pennies * 0.01);
            totalTextBox.Text = myTotal.ToString("c");            
            
        }                      
    }

}
