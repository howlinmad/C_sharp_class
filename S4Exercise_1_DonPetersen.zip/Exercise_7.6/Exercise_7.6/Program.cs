﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {            
            int[] array1 = new int[]{1,2,3,4,5};
            int[] array2 = new int[]{6,7,8,9,10};
            int[] array3 = new int[] { 1, 2, 3, 4 };
            Program Switch = new Program();

            //test 1
            Console.Out.WriteLine("Test 1:\nFirst Array contains: ");
            foreach (var item in array1)
            {
                Console.Out.Write(item.ToString()+ " ");
            }
            Console.Out.WriteLine("\nSecond Array contains: ");
            foreach (var item in array2)
            {
                Console.Out.Write(item.ToString() + " ");
            }
            Console.Out.WriteLine("\n\nSwitch them: ");
            
            Switch.SwitchThem(array1, array2);

            Console.Out.WriteLine("First Array now contains: ");
            foreach (var item in array1)
            {
                Console.Out.Write(item.ToString() + " ");
            }
            Console.Out.WriteLine("\nSecond Array now contains: ");
            foreach (var item in array2)
            {
                Console.Out.Write(item.ToString() + " ");
            }
            //Reset arrays for next test
            Switch.SwitchThem(array1, array2);
            //test 2
            Console.Out.WriteLine("\n\nTest 2: \nFirst Array contains: ");
            foreach (var item in array3)
            {
                Console.Out.Write(item.ToString() + " ");
            }
            Console.Out.WriteLine("\nSecond Array contains: ");
            foreach (var item in array2)
            {
                Console.Out.Write(item.ToString() + " ");
            }
            Console.Out.WriteLine("\n\nSwitch them: ");

            Switch.SwitchThem(array3, array2);



            
            Console.In.ReadLine();
            
        }

        public void SwitchThem(int[] array1, int[] array2)
        {
            if (array1.Length == array2.Length)
            {
                int[] temp = new int[array1.Length];
                for (int i = 0; i < array1.Length; i++)
                {
                    temp[i] = array1[i];
                    array1[i] = array2[i];
                    array2[i] = temp[i];
                }   
            
            }
            else
                Console.Out.WriteLine("Arrays must be of equal length");
        }
    }
}
