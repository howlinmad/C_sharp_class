﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;

namespace LastSurvivor
{
    class RingOfActors 
    {
        
        ArrayList ringArray = new ArrayList();        

        public RingOfActors()
        {
            //this was used when I was testing the position method
            //int[] actors = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
            //ringArray.AddRange(actors);
        }

        public void fillArray(int ring)
        {
            for (int i=0; i < ring; i++)
            {
                ringArray.Add(i+1);
            }
        }
        
        public void Position(int count)
        {
            int position=0;
            Console.Out.Write("      ");
            while (ringArray.Count >= 1)
            {
                    //Josephus formula
                    position = (position-1 + count) % ringArray.Count;
                    //foo
                    //foreach (object element in ringArray)
                    //{
                    //    Console.Write(element);
                    //}
                    Console.Out.Write(ringArray[position]);
                    ringArray.RemoveAt(position);
                
            }
            Console.Out.WriteLine();
            //Console.Out.Write(ringArray[0]+"\n");
            //Console.Out.WriteLine("\nThe actor who gets the part will be at position \""+ringArray[0]+"\" of the circle");
            ringArray.Clear();
        }

        public void displayElements()
        {
            foreach(object element in ringArray)
            {
                Console.Write(element);
            }
        }
    }
}
