﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;

namespace LastSurvivor
{
    class Program
    {
        static void Main(string[] args)
        {
            int ring = 1, count = 1; 
            //string num;           
            RingOfActors audition = new RingOfActors();
            
            //foo
            //Console.Out.WriteLine("Enter the number of Actors auditioning: ");
            //num = Console.ReadLine();
            //ring = int.Parse(num);
            //Console.Out.WriteLine("Enter the Count: ");
            //num = Console.ReadLine();
            //count = int.Parse(num);
            
            Console.Out.WriteLine("Actors  Count   Audition Order");

            ring = 1;
            count = 1;
            audition.fillArray(ring);
            Console.Out.Write(ring + "       " + count + " ");
            audition.Position(count);
            ring = 2;
            count = 1;
            audition.fillArray(ring);
            Console.Out.Write(ring + "       " + count + " ");
            audition.Position(count);
            ring = 2;
            count = 2;
            audition.fillArray(ring);
            Console.Out.Write(ring + "       " + count + " ");
            audition.Position(count);
            ring = 3;
            count = 1;
            audition.fillArray(ring);
            Console.Out.Write(ring + "       " + count + " ");
            audition.Position(count);
            ring = 3;
            count = 2;
            audition.fillArray(ring);
            Console.Out.Write(ring + "       " + count + " ");
            audition.Position(count);
            ring = 3;
            count = 3;
            audition.fillArray(ring);
            Console.Out.Write(ring + "       " + count + " ");
            audition.Position(count);
            ring = 4;
            count = 1;
            audition.fillArray(ring);
            Console.Out.Write(ring + "       " + count + " ");
            audition.Position(count);
            ring = 4;
            count = 2;
            audition.fillArray(ring);
            Console.Out.Write(ring + "       " + count + " ");
            audition.Position(count);
            ring = 4;
            count = 3;
            audition.fillArray(ring);
            Console.Out.Write(ring + "       " + count + " ");
            audition.Position(count);
            ring = 4;
            count = 4;
            audition.fillArray(ring);
            Console.Out.Write(ring + "       " + count + " ");
            audition.Position(count);
            ring = 5;
            count = 1;
            audition.fillArray(ring);
            Console.Out.Write(ring + "       " + count + " ");
            audition.Position(count);
            ring = 5;
            count = 2;
            audition.fillArray(ring);
            Console.Out.Write(ring + "       " + count + " ");
            audition.Position(count);
            ring = 5;
            count = 3;
            audition.fillArray(ring);
            Console.Out.Write(ring + "       " + count + " ");
            audition.Position(count);
            ring = 5;
            count = 4;
            audition.fillArray(ring);
            Console.Out.Write(ring + "       " + count + " ");
            audition.Position(count);
            ring = 5;
            count = 5;
            audition.fillArray(ring);
            Console.Out.Write(ring + "       " + count + " ");
            audition.Position(count);
            ring = 6;
            count = 1;
            audition.fillArray(ring);
            Console.Out.Write(ring + "       " + count + " ");
            audition.Position(count);
            ring = 6;
            count = 2;
            audition.fillArray(ring);
            Console.Out.Write(ring + "       " + count + " ");
            audition.Position(count);
            ring = 6;
            count = 3;
            audition.fillArray(ring);
            Console.Out.Write(ring + "       " + count + " ");
            audition.Position(count);
            ring = 6;
            count = 4;
            audition.fillArray(ring);
            Console.Out.Write(ring + "       " + count + " ");
            audition.Position(count);
            ring = 6;
            count = 5;
            audition.fillArray(ring);
            Console.Out.Write(ring + "       " + count + " ");
            audition.Position(count);
            ring = 6;
            count = 6;
            audition.fillArray(ring);
            Console.Out.Write(ring + "       " + count + " ");
            audition.Position(count);
            ring = 7;
            count = 1;
            audition.fillArray(ring);
            Console.Out.Write(ring + "       " + count + " ");
            audition.Position(count);
            ring = 7;
            count = 2;
            audition.fillArray(ring);
            Console.Out.Write(ring + "       " + count + " ");
            audition.Position(count);
            ring = 7;
            count = 3;
            audition.fillArray(ring);
            Console.Out.Write(ring + "       " + count + " ");
            audition.Position(count);
            ring = 7;
            count = 4;
            audition.fillArray(ring);
            Console.Out.Write(ring + "       " + count + " ");
            audition.Position(count);
            ring = 7;
            count = 5;
            audition.fillArray(ring);
            Console.Out.Write(ring + "       " + count + " ");
            audition.Position(count);
            ring = 7;
            count = 6;
            audition.fillArray(ring);
            Console.Out.Write(ring + "       " + count + " ");
            audition.Position(count);
            ring = 7;
            count = 7;
            audition.fillArray(ring);
            Console.Out.Write(ring + "       " + count + " ");
            audition.Position(count);
            ring = 8;
            count = 1;
            audition.fillArray(ring);
            Console.Out.Write(ring + "       " + count + " ");
            audition.Position(count);
            ring = 8;
            count = 2;
            audition.fillArray(ring);
            Console.Out.Write(ring + "       " + count + " ");
            audition.Position(count); 
            ring = 8;
            count = 3;
            audition.fillArray(ring);
            Console.Out.Write(ring + "       " + count + " ");
            audition.Position(count); 
            ring = 8;
            count = 4;
            audition.fillArray(ring);
            Console.Out.Write(ring + "       " + count + " ");
            audition.Position(count); 
            ring = 8;
            count = 5;
            audition.fillArray(ring);
            Console.Out.Write(ring + "       " + count + " ");
            audition.Position(count); 
            ring = 8;
            count = 6;
            audition.fillArray(ring);
            Console.Out.Write(ring + "       " + count + " ");
            audition.Position(count); 
            ring = 8;
            count = 7;
            audition.fillArray(ring);
            Console.Out.Write(ring + "       " + count + " ");
            audition.Position(count); 
            ring = 8;
            count = 8;
            audition.fillArray(ring);
            Console.Out.Write(ring + "       " + count + " ");
            audition.Position(count);
            ring = 9;
            count = 1;
            audition.fillArray(ring);
            Console.Out.Write(ring + "       " + count + " ");
            audition.Position(count);
            ring = 9;
            count = 2;
            audition.fillArray(ring);
            Console.Out.Write(ring + "       " + count + " ");
            audition.Position(count);
            ring = 9;
            count = 3;
            audition.fillArray(ring);
            Console.Out.Write(ring + "       " + count + " ");
            audition.Position(count);
            ring = 9;
            count = 4;
            audition.fillArray(ring);
            Console.Out.Write(ring + "       " + count + " ");
            audition.Position(count);
            ring = 9;
            count = 5;
            audition.fillArray(ring);
            Console.Out.Write(ring + "       " + count + " ");
            audition.Position(count);
            ring = 9;
            count = 6;
            audition.fillArray(ring);
            Console.Out.Write(ring + "       " + count + " ");
            audition.Position(count);
            ring = 9;
            count = 7;
            audition.fillArray(ring);
            Console.Out.Write(ring + "       " + count + " ");
            audition.Position(count);
            ring = 9;
            count = 8;
            audition.fillArray(ring);
            Console.Out.Write(ring + "       " + count + " ");
            audition.Position(count);
            ring = 9;
            count = 9;
            audition.fillArray(ring);
            Console.Out.Write(ring + "       " + count + " ");
            audition.Position(count);

            
            //I was trying to get the program to display using a loop.
            //this is the closest I came but I couldn't get it to work.
            //while (ring <= 9)
            //{
                
            //    audition.fillArray(ring);
            //    Console.Out.Write(ring + "       " + count + " ");
            //    for(int i=0;i<=ring;i++)
            //    {
            //        count = i+1;
            //        audition.Position(count);
            //    }   
                
            //    ring++;
                
            //}


            //audition.fillArray(ring);
            //audition.Position(count);
           
            //foo
            //audition.displayElements();
            Console.ReadLine();
        }
    }
}
