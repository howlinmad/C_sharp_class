﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Out.WriteLine("Knowledge is Power");
            Console.Out.WriteLine("\nKnowledge \nIs \nPower");
            Console.Out.WriteLine("\n======================");
            Console.Out.WriteLine("| Knowledge is Power |");
            Console.Out.WriteLine("======================");
            Console.In.ReadLine();
        }
    }
}
