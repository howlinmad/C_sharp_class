﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
           
                string done;
                Console.Out.WriteLine("Enter a string (type \"DONE\" to quit): ");
                done = Console.ReadLine();
                done = done.ToUpper();
                while (done != "DONE")
                {

                    if (done.Length > 20)
                    {
                        StringTooLongException problem = new StringTooLongException("String is too long");
                        throw problem;
                    }



                    Console.Out.WriteLine("Enter a string (type \"DONE\" to quit): ");
                    done = Console.ReadLine();
                    done = done.ToUpper();
                }
            
            
            //Console.ReadLine();
        
        }
        
    }
}
