﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class StringTooLongException: Exception 
    {
        public StringTooLongException(string  message):base(message)
        {
            Console.Out.WriteLine("String is too long");
        }
    }
}
