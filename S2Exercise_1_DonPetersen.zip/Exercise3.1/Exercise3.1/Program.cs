﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            double x1=0, x2=0, y1=0, y2=0, distance;

            Console.Out.WriteLine("Enter first x coord: ");
            string line = Console.ReadLine();
            x1 = double.Parse(line);

            Console.Out.WriteLine("Enter first y coord: ");
            line = Console.ReadLine();
            y1 = double.Parse(line);

            Console.Out.WriteLine("Enter second x coord: ");
            line = Console.ReadLine();
            x2 = double.Parse(line);

            Console.Out.WriteLine("Enter second y coord: ");
            line = Console.ReadLine();
            y2 = double.Parse(line);

            distance = Math.Sqrt(Math.Pow((x2 - x1), 2)
                + Math.Pow((y2 - y1), 2));

            Console.Out.WriteLine("The distance between the coords is: "+distance.ToString("F2"));
            Console.In.ReadLine();
        }
    }
}
