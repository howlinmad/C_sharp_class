﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindowsFormsApplication1
{
    class PairOfDice
    {
        private Die die1, die2;
        private int totalRolled;


        public PairOfDice()
        {
            die1 = new Die();
            die2 = die1;
            totalRolled = die1.Roll() + die2.Roll();

        }

        public int Roll()
        {
            totalRolled = die1.Roll() + die2.Roll();
            return totalRolled;
        }

        public int GetTotalRolled()
        {
            return totalRolled;
        }
    }
}
