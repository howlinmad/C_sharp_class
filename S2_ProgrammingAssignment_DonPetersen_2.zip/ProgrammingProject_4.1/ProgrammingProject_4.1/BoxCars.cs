﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
      
    
    
    
    
    public partial class BoxCars : Form
    {
        public BoxCars()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            int boxcarsRolled = 0, totalRolled;

            PairOfDice dice = new PairOfDice();


            for (int roll = 0; roll <= 1000; roll++)
            {
                totalRolled = dice.Roll();
                if (totalRolled == 12)
                {
                    boxcarsRolled++;
                }
               
            }
            boxCarsTextBox.Text = boxcarsRolled.ToString();
        }
    }
}
