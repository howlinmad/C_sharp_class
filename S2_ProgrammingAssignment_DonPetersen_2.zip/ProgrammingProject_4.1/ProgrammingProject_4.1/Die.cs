﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindowsFormsApplication1
{
    class Die
    {
        private const int MAX = 6;
        private int faceValue;
        private Random generator;

        public Die()
        {
            generator = new Random(DateTime.Now.Millisecond);
            faceValue = 1;
        }

        public int Roll()
        {
            faceValue = generator.Next(MAX) + 1;
            return faceValue;
        }

        public int FaceValue
        {
            get
            {
                return faceValue;
            }
            set
            {

                faceValue = value;
            }
        }

        public void SetFaceValue(int face)
        {
            faceValue = face;
        }

        public int GetFaceValue()
        {
            return faceValue;
        }

        public override string ToString()
        {
            return faceValue.ToString();
        }
    }


}
