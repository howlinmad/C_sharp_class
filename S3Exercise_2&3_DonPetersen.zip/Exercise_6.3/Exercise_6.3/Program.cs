﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            int x=0, y=0, w=0, z=0;
            float average=0;
            
            Program Number = new Program();
            Console.Out.WriteLine("Enter two or four Numbers to find their average: "
                + "\n(if only using two numbers enter 0 for third and fourth number)" + "\nFirst Number: ");
            //Convert string to integer
            string number = Console.ReadLine();
            x = int.Parse(number);
            Console.Out.WriteLine("Second Number: ");
            number = Console.ReadLine();
            y = int.Parse(number);
            Console.Out.WriteLine("Third Number: ");
            number = Console.ReadLine();
            w = int.Parse(number);
            Console.Out.WriteLine("Fourth Number: ");
            number = Console.ReadLine();
            z = int.Parse(number);
            //Call Average method
            if (z == 0)
            {
                average = Number.Average(x, y);
                
            }
            else if (z > 0 || w > 0)
            { 
                average = Number.Average(x, y, w, z);
            }
            //Output Results
            Console.Out.WriteLine("The average of the numbers is: "
                + average);
            Console.In.ReadLine();
        }
    
        //Exercise 6.1 Average method    
        public float Average(int x, int y)
    {
        //Calculate average and return float variable     
        float average = (x + y) / (float)2;
        return average;
    }
        //Exercise 6.3 overloaded method
        public float Average(int a, int b, int c, int d)
    {
        float average = (a + b + c + d) / (float)4;
        return average;
    }
        }
    }

