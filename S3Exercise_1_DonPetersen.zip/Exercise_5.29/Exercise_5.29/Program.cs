﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            string phrase;
            Program Count = new Program();
            Console.Out.WriteLine("Type a word or phrase: ");
            phrase = Console.ReadLine().ToLower();
            int total = Count.CountA(phrase);

            Console.Out.WriteLine("There are " + total 
                +" letter a's in your word or phrase.");
            Console.In.ReadLine();
    
    
        }
    
    public int CountA(string phrase)
        {
        int total = 0;    
        for (int i = 0; i < phrase.Length; i++)
            {
                if (phrase[i] == 'a')
                {
                    total++;
                }
            }
        return total;
        }
    }


}

