﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public int RandomInRange(int min, int max)
        {
            System.Random ranNumber = new Random(DateTime.Now.Millisecond);
            int number = (ranNumber.Next(max - min +1)) + min;
            return number;
        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            
            string minInput = minTextBox.Text;
            string maxInput = maxTextBox.Text;
            int min, max;
            min = Convert.ToInt32(minInput);
            max = Convert.ToInt32(maxInput);
            
            numTextBox.Text = RandomInRange(min, max).ToString();

        }
    }
}
