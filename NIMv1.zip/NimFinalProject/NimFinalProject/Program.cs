﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Program nim = new Program();
            int piles, sticks;
            string num;

            nim.gameIntro();


            Console.Out.Write("\n\n How many Piles for today's game? ");
            num = Console.ReadLine();            
            piles = Convert.ToInt32(num);  
            
            int[] numOfPiles = new int[piles];
            //test array input
            //Console.Out.Write(numOfPiles.Length);
            int pileNumber=1;
            for (int i=0; i < numOfPiles.Length; i++)
            {
            Console.Out.Write(" Enter the number sticks for pile "+pileNumber+":");
            num = Console.ReadLine();
            sticks = Convert.ToInt32(num);
            numOfPiles[i] = sticks;
            pileNumber++;
            }
            //to test the elements of the array.
            Console.Out.Write("\nsticks in each pile: ");
            for (int i = 0; i < numOfPiles.Length; i++)
            {
                Console.Out.Write(numOfPiles[i]+" ");
            }


                Console.ReadLine();
        }
        public void gameIntro()
        {
            Console.Out.WriteLine("\n\t\t\t    Time to play Nim!");
            Console.Out.WriteLine("\n\n\t   The game where whoever picks up the last stick wins!");
        }
      

    }
}
