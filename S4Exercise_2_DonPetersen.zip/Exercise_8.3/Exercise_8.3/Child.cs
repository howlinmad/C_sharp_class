﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Child : Parent
    {
        public Child():base()
        {
                        
            Console.Out.WriteLine("I am the Child Class");
            
        }
    }
}
