﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Parent
    {
        public Parent()
        {
            Console.Out.WriteLine("I am the Parent Class");
        }
    }
}
