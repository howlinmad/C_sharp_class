﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            string path;
            string[] readText;

            Node n = new Node("andy");
            //Node copy = n.copy();
            n.ToString();
            //n.copy();
           // n.reverse();
            Console.WriteLine("n=" + n.ToString());
            //Console.WriteLine("copy=" + copy.ToString());


            path = @"C:\Users\Don\Documents\Visual Studio 2010\Projects\PalindromeNode\PalindromeNode\data.txt";
            readText = File.ReadAllLines(path);

            //string a = "a";
            //char c = Convert.ToChar(a);


            //foreach (string s in readText)
            //{
                
            //    Node node = new Node(s);
            //    node.ToString();
            //    node.copy();
            //    node.reverse();
            //    //node.Print();
            //}
           
       
            Console.ReadLine();
        }
    }
}
