﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Node
    {


        //private string path;
        //private string[] readText;
        char c;
        Node next;
        
       


        public Node()
        {
            //path = @"C:\Users\Don\Documents\Visual Studio 2010\Projects\PalindromeNode\PalindromeNode\data.txt";

            //readText = File.ReadAllLines(path);
            //if (File.Exists(path))
            //{
            //    foreach (string s in readText)
            //    {
            //        Console.WriteLine(s);
            //    }
            //}

            
        }

       
        
        public Node(char c)
        {
            this.c = c;
            next = null;
        }

        public Node(string s)
        {
            Node currentNode = this;          
            foreach (char c in s)
            {
              
                    currentNode.c = c;   //'a'
                    Node nextNode = new Node(c); //makes new node
                    currentNode.next = nextNode; //points to 'n'
                    currentNode = nextNode; //go to 'n' node, repeat
               
                    
                    
                    //Console.Out.Write(c);
                
                              
            }
            //Console.Out.WriteLine();

        }
  
        public void copy()
        {
            Node currentNode = this; 
            
            while (currentNode.next != null)// stop when next pointer is null
            {    //currentNode makes an 'a'
                
                Node nextNode = new Node(c); //make a new node 'a'
                currentNode.next = currentNode; //move to next item in currentNode list
                nextNode.next = nextNode;
                
                
                //Console.Out.Write(c);
            }
        }
//This is what I did from the post you made about it. Ran out of time before I could get it right.  
        public void reverse()
        {
            Node  nextNode, prev;
            Node currentNode = this;            
            prev = null;
            while (currentNode != null)
            {
                nextNode = currentNode.next; //nextnode points to next node in current list
                currentNode.next = prev; //first node points to null
                prev = currentNode; //prev goes to first node
                currentNode = nextNode; //current node  
            }
            
            //Console.Out.Write(currentNode);
        }
//I ran out of time and didn't get to this one at all. I commmented it out so that the progarm would compile. 
        //public bool equals( )
        //{

        //}

        public string ToString()
        {
            String result = "";
            Node current = this;
            while (current.next != null)//stop when the next pointer is null
            {
                result += current.c; //add node char to the string
                current = current.next;
            }
            return result;

        }

        //public void Print()
        //{
        //    Console.Out.Write(c);
        //}



    }
}
// I feel like I learned a lot from doing this assignment even though 
// I wasn't able to finshed it. Thank you for going the extra mile and 
// helping me with this.
// I think the hardest part was not being able to test my work very often. 
// I rely heavily on trying something, seeing how it affects the program and then
// adjusting and making another guess. Learning how to use the breakpoint method 
// to check what was happening was huge at figuring things out faster.  